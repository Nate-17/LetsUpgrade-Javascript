let jobdetails=[
     {
      name:"Ramesh",
      age:21,
      city:"Pune",
      salary:42000,
     },

     {
        name:"Shivraj",
        age:27,
        city:"Mumbai",
        salary:8642386,
       },
       {
        name:"Kriti",
        age:22,
        city:"Nagpur",
        salary:12000,
       },
       {
        name:"Nupoor",
        age:26,
        city:"Goa",
        salary:236754,
       },
       {
        name:"Yash",
        age:24,
        city:"Bihar",
        salary:873467,
       },
        
];

function display(superarray){

     let tabledata="";
     superarray.forEach(function(jobdetail,index){
            let currentrow =`<tr>
            <td>${jobdetail.name}</td>
            <td>${jobdetail.age}</td>
            <td>${jobdetail.city}</td> 
            <td>${jobdetail.salary}</td>
            <td><button onclick='deleteperson(${index})'>delete</button></td> 
            </tr>`;


            tabledata+=currentrow;
     });

document.getElementById('tdata').innerHTML=tabledata;
}
display(jobdetails);


  
function addperson(e) {
  e.preventDefault();
  let jobdetail = {};
  let name = document.getElementById("name").value;
  let age = document.getElementById("age").value;
  let city = document.getElementById("city").value;
  let salary = document.getElementById("salary").value;
  jobdetail.name = name;
  jobdetail.age = Number(age);
  jobdetail.city = city;
  jobdetail.salary = Number(salary);

  jobdetails.push(jobdetail);

  display(superarray);

  document.getElementById("name").value = "";
  document.getElementById("age").value = "";
  document.getElementById("city").value = "";
  document.getElementById("salary").value = "";
}

function searchByName() {
    let searchValue = document.getElementById("searchName").value;
  
    let newdata = jobdetails.filter(function (jobdetail) {
      return (
        jobdetail.name.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
      );
    });
  
    display(newdata);
  }

  function searchBycity() {
    let searchValue = document.getElementById("searchcity").value;
  
    let newdata1 = jobdetails.filter(function (jobdetail) {
      return (
        jobdetail.city.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
      );
    });
  
    display(newdata1);
  }


  function deleteperson(index) {
    jobdetails.splice(index, 1);
    display(jobdetails);
  }