window.onload=function(){

  let initialbusdetails=[];

   if(localStorage.getItem("busdetails")==null)
   {
     let stringbusdetails=JSON.stringify(initialbusdetails);
     localStorage.setItem("busdetails",stringbusdetails);
   }
}
function display(superarray = undefined){

    let tabledata="";
    let busdetails;
    if (superarray == undefined) {
    busdetails=JSON.parse(localStorage.getItem("busdetails"));
    } else {
      busdetails = superarray;
    }
    busdetails.forEach(function(busdetail,index){
           let currentrow =`<tr>
           <td>${busdetail.name}</td>
           <td>${busdetail.source}</td>
           <td>${busdetail.destination}</td> 
           <td>${busdetail.numbers}</td>
           <td>${busdetail.passengercapacity}</td>
           <td><button onclick='deletebus(${index})'>delete</button></td>
           </tr>`;


           tabledata+=currentrow;
    });

document.getElementById('tdata').innerHTML=tabledata;
}
display();
    

function addbus(e) {
    e.preventDefault();
    let busdetail = {};
    let name = document.getElementById("name").value;
    let source = document.getElementById("source").value;
    let destination = document.getElementById("destination").value;
    let numbers = document.getElementById("numbers").value;
    let passengercapacity = document.getElementById("passengercapacity").value;
    busdetail.name = name;
    busdetail.source = source;
    busdetail.destination = destination;
    busdetail.numbers = Number(numbers);
    busdetail.passengercapacity = Number(passengercapacity);  
   
  
    let busdetails = JSON.parse(localStorage.getItem("busdetails"));
    busdetails.push(busdetail);
    localStorage.setItem("busdetails", JSON.stringify(busdetails));

    display();


    document.getElementById("name").value = "";
    document.getElementById("source").value = "";
    document.getElementById("destination").value = "";
    document.getElementById("numbers").value = "";
    document.getElementById("passengercapacity").value = "";
  }

  function searchBySource() {
    let searchValue = document.getElementById("searchsource").value;
    let busdetails = JSON.parse(localStorage.getItem("busdetails"));
    let newdata = busdetails.filter(function (busdetail) {
      return (
        busdetail.source.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
      );
    });
  
    display(newdata);
  }

  function searchByDestination() {
    let searchValue = document.getElementById("searchdestination").value;
    let busdetails = JSON.parse(localStorage.getItem("busdetails"));
    let newdata1 = busdetails.filter(function (busdetail) {
      return (
        busdetail.destination.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
      );
    });
  
    display(newdata1);
  }


  function deletebus(index) {
    let busdetails = JSON.parse(localStorage.getItem("busdetails"));
    busdetails.splice(index, 1);
    localStorage.setItem("busdetails", JSON.stringify(busdetails));
    display();
  }