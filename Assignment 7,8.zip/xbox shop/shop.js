let products = [
    {
      id: 1,
      name: "Borderlands 3",
      console:"PC",
      price: 1200,
      genre:"Action,Shooter",
      image: "image1.jpeg",
      description: "Action packed",
    },
    {
      id: 2,
      name: "Bioshock Infinite",
      console: "PC",
      price: 1500,
      genre:"Action,Shooter",
      image: "image2.jpeg",
      description: "Good Scares",
    },
  
    {
      id: 3,
      name: "Watchdogs",
      console: "PC",
      price: 900,
      genre:"Action,Shooter,Open World",
      image: "image3.jpeg",
      description: "Hack the World",
    },
  
    {
      id: 4,
      name: "Tomb Raider",
      console: "PC",
      price: 3000,
      genre:"Action, Adventure",
      image: "image4.jpeg",
      description: "Dive in Mysteries",
    },
  
    {
      id: 5,
      name: "Red Dead Redemption",
      console: "PC",
      price: 1300,
      genre:"Action,Shooter,Open World",
      image: "image5.jpeg",
      description: "Cowboy Style Shooter",
    },
  
    {
      id: 6,
      name: "Farcry Primal",
      console: "PC",
      price: 1500,
      genre:"Action,Shooter,Open World",
      image: "image6.jpeg",
      description: "Ride Mammoth and hunt",
    },

    {
        id: 7,
        name: "Call of Duty MW3",
        console:"PC",
        price: 699,
        genre:"Action,Shooter",
        image: "image7.jpeg",
        description: "Great guns and graphics",
      },

      {
        id: 8,
        name: "Rage 2",
        console:"PC",
        price: 2100,
        genre:"Action,Shooter",
        image: "image8.jpeg",
        description: "Action packed",
      },

      {
        id: 9,
        name: "Evolve",
        console:"PC",
        price: 2500,
        genre:"Action,Shooter",
        image: "image9.jpeg",
        description: "Horror",
      },

      {
        id: 10,
        name: "Destiny 2",
        console:"PS5",
        price: 2999,
        genre:"Action,Shooter,Open World",
        image: "image10.jpeg",
        description: "Team Play",
      },

      {
        id: 11,
        name: "GTA V",
        console:"Xbox",
        price: 500,
        genre:"Action,Shooter,Open World",
        image: "image11.jpeg",
        description: "Fun to play",
      },

      {
        id: 12,
        name: "Call of Duty Black Ops 3",
        console:"Xbox",
        price: 4399,
        genre:"Action,Shooter",
        image: "image12.jpeg",
        description: "Good Story",
      },
  ];
  
  cart = [];
  let count=0;
  
  function displayProducts(productsData, who = "productwrapper") {
    let productsString = "";
  
    productsData.forEach(function (product, index) {
      let { id, name, image,genre, description, price, console } = product;
  
      if (who == "productwrapper") {
        productsString += ` <div class="product">
          <div class="prodimg">
            <img src="gamelist/${image}" width="100%" />
          </div>
          <h3>${name}</h3>
          <p>Price : ${price}$</p>
          <p>console : ${console}</p>
          <p>Genre: ${genre}</p>
          <p>${description}</p>
          <p>
            <button onclick="addToCart(${id})">Add to Cart</button>
          </p>
        </div>`;
      } else if (who == "cart") {
        productsString += ` <div class="product">
          <div class="prodimg">
            <img src="gamelist/${image}" width="100%" />
          </div>
          <h3>${name}</h3>
          <p>Price : ${price}$</p>
          <p>console : ${console}</p>
          <p>Genre: ${genre}</p>
          <p>${description}</p>
          <p>
            <button onclick="removeFromCart(${id})">Remove from Cart</button>
          </p>
        </div>`;
      }
    });
  
    document.getElementById(who).innerHTML = productsString;
  }
  
  displayProducts(products);
  
  function searchProduct(searchValue) {
    let searchedProducts = products.filter(function (product, index) {
      let searchString =
        product.name + " " + product.color + " " + product.description;
  
      return searchString.toUpperCase().indexOf(searchValue.toUpperCase()) != -1;
    });
  
    displayProducts(searchedProducts);
  }
  
  
  function getProductByID(productArray, id) {
    return productArray.find(function (product) {
      return product.id == id;
    });
  }
  
  let flag=false;
  function addToCart(id) {
  flag=false;
    let item = getProductByID(products, id);
  
    cart.forEach(function(element){
        if(element.id==item.id){
            flag=true;
            
        }
        
  
    })
    if (flag) {
        alert("AlREADY IN CART");
      return 0;
    }
    cart.push(item);
    count+=1;
    document.getElementById("numb").innerText=count;
    let type="cartd";
    let place="cartcard";
    displayProducts(cart, "cart");
  
  }

  function removeFromCart(id) {
    // getting the index based on id
    let index = cart.findIndex(function (product) {
      return product.id == id;
    });
  
    //   removing from cart based on index
    cart.splice(index, 1);
    displayProducts(cart, "cart");
  }

  function filter(){
    let minv=document.getElementById("minp").value;
    let maxv = document.getElementById("maxp").value;
    if(minv==0 && maxv==0) {
         displayProducts(products);
    } else {
    let items= products.filter(function(itemsl){
        return itemsl.price>=minv && itemsl.price<=maxv;
    })
     displayProducts(items);
    document.getElementById("minp").value="";
      document.getElementById("maxp").value="";
  }
}