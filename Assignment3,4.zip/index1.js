function change1(){
    const ele1 = document.getElementById("car")
    const newurl1="https://www.chevrolet.com/content/dam/chevrolet/na/us/english/index/vehicles/2021/performance/camaro/colorizer/01-images/2021-camaro-2ss-g7c-colorizer.jpg?imwidth=420"
    ele1.src=newurl1
}

function change2(){
    const ele2 = document.getElementById("car")
    const newurl2="https://www.wmotors.ae/img/wmotors_lykanhypersport_gallery_img_04.jpg"
    ele2.src=newurl2
}


function change3(){
    const ele3 = document.getElementById("car")
    const newurl3="https://media.wired.com/photos/5926c0518d4ebc5ab806b5c3/master/pass/TeslaSHP.jpg" 
    ele3.src=newurl3
}
